#include "Pump.h"

Pump::Pump(const int pin) : Switchable(pin)
{
    
}
